# python3.6
#%% 
import random
import json
from paho.mqtt import client as mqtt_client
import time
from math import radians, degrees, cos, sqrt
import pandas as pd
import numpy as np
from ParticleFilter import PF

def distance(p1, p2):
    return sqrt((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2)

# def get_gi():
#     with open('LAB.txt', 'r') as gi_file:
#         gi = gi_file.read().split('\n\n')
#     polygons = eval(gi[0].replace('\n','')[7:])
#     polygon_id = np.array(list(polygons.keys()))
#     polygons = np.array(tuple(((v[0],v[1]) for p in polygons.values() for v in p))).reshape(len(polygons),4,2).transpose(2,1,0)
#     beacon_str = gi[1].replace('\n','')[21:-3].split("),'")
#     bx = np.empty(len(beacon_str))
#     by = np.empty(len(beacon_str))
#     for i, b in enumerate(beacon_str):
#         idx = b.index('x=')
#         bx[i] = float(b[idx+2:b.index(', ',idx)])
#         idx = b.index('y=')
#         by[i] = float(b[idx+2:b.index(', ',idx)])
#         #idx = b.index('z=')
#         #bz[i] = int(b[idx+2:b.index(', ',idx)])
#     beacon_loc = pd.DataFrame(columns=['bID',0,1])
#     beacon_loc['bID'] = np.array(list(map(lambda b:b[:15], beacon_str)))
#     beacon_loc[0] = bx; beacon_loc[1] = by
#     beacon_loc = beacon_loc.set_index('bID')
#     center = (polygons.max(axis=(1,2))+polygons.min(axis=(1,2)))/2
#     def geo2meter(coordinate):
#         x = radians(coordinate[0] - center[0]) * 6371000 * cos(radians(center[1]))
#         y = radians(coordinate[1] - center[1]) * 6371000
#         return (x,y)
#     def meter2geo(coordinate):
#         lon = center[0] + degrees(coordinate[0] / (6371000 * cos(radians(center[1]))))
#         lat = center[1] + degrees(coordinate[1] / 6371000)
#         return (lon, lat)
#     polygons[0] = np.radians(polygons[0]-center[0]) * 6371000 * cos(radians(center[1]))
#     polygons[1] = np.radians(polygons[1]-center[1]) * 6371000
#     beacon_loc[0] = np.radians(beacon_loc[0]-center[0]) * 6371000 * cos(radians(center[1]))
#     beacon_loc[1] = np.radians(beacon_loc[1]-center[1]) * 6371000
#     return polygons, polygon_id, beacon_loc, geo2meter, meter2geo
# polygons, polygon_id, beacon_loc, geo2meter, meter2geo = get_gi()


polygons = np.array([[[114.26362049288582,22.33583315382333],[114.26378258286002,22.33583221676905],[114.26378460898417,22.33522968940531],[114.26362454513605,22.33522968940531]]]) 
polygons = polygons.reshape(len(polygons),4,2).transpose(2,1,0)
beacon_loc = pd.DataFrame(columns=['bID',0,1])
beacon_loc[0] = np.array((114.26368634, 114.26369343)); beacon_loc[1] = np.array([22.33524281, 22.33582097])
beacon_loc['bID'] = np.array(['mtrec-02', 'mtrec-03'])
beacon_loc = beacon_loc.set_index('bID')
center = (polygons.max(axis=(1,2))+polygons.min(axis=(1,2)))/2
def geo2meter(coordinate):
    x = radians(coordinate[0] - center[0]) * 6371000 * cos(radians(center[1]))
    y = radians(coordinate[1] - center[1]) * 6371000
    return (x,y)
def meter2geo(coordinate):
    lon = center[0] + degrees(coordinate[0] / (6371000 * cos(radians(center[1]))))
    lat = center[1] + degrees(coordinate[1] / 6371000)
    return (lon, lat)
polygons[0] = np.radians(polygons[0]-center[0]) * 6371000 * cos(radians(center[1]))
polygons[1] = np.radians(polygons[1]-center[1]) * 6371000
beacon_loc[0] = np.radians(beacon_loc[0]-center[0]) * 6371000 * cos(radians(center[1]))
beacon_loc[1] = np.radians(beacon_loc[1]-center[1]) * 6371000
pf = PF((polygons, beacon_loc))




broker = 'nam1.cloud.thethings.network'
port = 1883
topic = "#"
# generate client ID with pub prefix randomly
client_id = f'python-mqtt-{random.randint(0, 100)}'
username = 'ust-demo-lora@ttn'
password = 'NNSXS.FE35NNNLTG2KRG446KOYZXC7QANBJG4HRRJ4FGI.4JGJCFCF227ZLD7YXS5JAVQ33YQM5Z27AEASC5F5TLYFYFLSY5EQ'


def write_json(new_data, filename):
    with open("mqtt-data.json", 'r+') as file:
        file_data = json.load(file)
        file_data["useful_data"].append(new_data)
        file.seek(0)
        json.dump(file_data, file, indent=2)


def connect_mqtt() -> mqtt_client:
    def on_connect(client, userdata, flags, rc):
        if rc == 0:
            print("Connected to MQTT Broker!")
        else:
            print("Failed to connect, return code %d\n", rc)

    client = mqtt_client.Client(client_id)
    client.username_pw_set(username, password)
    client.on_connect = on_connect
    client.connect(broker, port)
    return client


def subscribe(client: mqtt_client):
    def on_message(client, userdata, msg):
        global pf
        # print(f"Received `{msg.payload.decode()}` from `{msg.topic}` topic")
        payload_data = json.loads(msg.payload.decode())
        # print(time.time(), payload_data)

        for r in payload_data['uplink_message']['rx_metadata']:
            print(time.time(), payload_data['end_device_ids']['device_id'], r['gateway_ids']['gateway_id'], r['rssi'])
        # TODO: feed pf
        beacon_batch = pd.DataFrame(columns=['bID', 'rssi'])
        tag_id = payload_data['end_device_ids']['device_id']
        gateways = [g['gateway_ids']['gateway_id'] for g in payload_data['uplink_message']['rx_metadata']]
        rssi = [r['rssi'] for r in payload_data['uplink_message']['rx_metadata']]
        beacon_batch['bID'] = gateways; beacon_batch['rssi'] = rssi

        #
        print(tag_id, beacon_batch)
        pf.feed_data(round(time.time()), beacon_batch)
        print(pf.tracked, meter2geo(pf.pos_estimate))
        #print(payload_data['uplink_message']['rx_metadata'])

    client.subscribe(topic)
    client.on_message = on_message



def run():
    client = connect_mqtt()
    subscribe(client)
    client.loop_forever()


if __name__ == '__main__':
    run()

# %%
